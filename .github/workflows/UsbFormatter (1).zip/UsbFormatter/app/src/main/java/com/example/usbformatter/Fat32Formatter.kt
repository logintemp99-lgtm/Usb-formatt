package com.example.usbformatter

import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Quick-formats a drive: MBR + one FAT32 partition. */
object Fat32Formatter {
    private const val PART_START = 2048L
    private const val RESERVED = 32
    private const val FATS = 2

    fun format(dev: UsbMassStorage, label: String, progress: (Int) -> Unit) {
        val bps = dev.blockSize
        require(bps in intArrayOf(512, 1024, 2048, 4096)) { "Unsupported sector size $bps" }
        val volSectors = dev.blockCount - PART_START
        val bytes = volSectors * bps
        require(bytes >= 128L * 1024 * 1024) { "Drive too small for FAT32 (min 128 MB)" }

        val clusterBytes = when {
            bytes <= 256L shl 20 -> 1024
            bytes <= 8L shl 30 -> 4096
            bytes <= 16L shl 30 -> 8192
            bytes <= 32L shl 30 -> 16384
            else -> 32768
        }
        val spc = maxOf(1, clusterBytes / bps)
        val eps = bps / 4
        val fatSz = ((volSectors - RESERVED + eps * spc + FATS - 1) / (eps * spc + FATS))
        val clusters = (volSectors - RESERVED - FATS * fatSz) / spc
        require(clusters >= 65525) { "Drive too small for FAT32" }
        val dataStart = RESERVED + FATS * fatSz

        // 1) MBR
        val mbr = ByteBuffer.allocate(bps).order(ByteOrder.LITTLE_ENDIAN)
        mbr.position(446)
        mbr.put(0).put(0xFE.toByte()).put(0xFF.toByte()).put(0xFF.toByte())
        mbr.put(0x0C).put(0xFE.toByte()).put(0xFF.toByte()).put(0xFF.toByte())
        mbr.putInt(PART_START.toInt()).putInt(volSectors.toInt())
        mbr.put(510, 0x55).put(511, 0xAA.toByte())
        dev.write(0, mbr.array())
        progress(2)

        // 2) Wipe reserved area, both FATs and the root cluster
        zero(dev, PART_START, RESERVED.toLong()) {}
        val fatTotal = FATS * fatSz
        zero(dev, PART_START + RESERVED, fatTotal) { progress(2 + (it * 90 / 100).toInt()) }
        zero(dev, PART_START + dataStart, spc.toLong()) {}

        // 3) Boot sector, FSInfo (plus backups at sector 6/7)
        val boot = bootSector(bps, spc, fatSz, volSectors, label)
        val fsi = fsInfo(bps, clusters - 1)
        dev.write(PART_START + 0, boot); dev.write(PART_START + 1, fsi)
        dev.write(PART_START + 6, boot); dev.write(PART_START + 7, fsi)

        // 4) First FAT sector in both FATs
        val fat = ByteBuffer.allocate(bps).order(ByteOrder.LITTLE_ENDIAN)
        fat.putInt(0x0FFFFFF8).putInt(0x0FFFFFFF).putInt(0x0FFFFFFF)
        dev.write(PART_START + RESERVED, fat.array())
        dev.write(PART_START + RESERVED + fatSz, fat.array())
        progress(100)
    }

    private fun zero(dev: UsbMassStorage, lba: Long, count: Long, p: (Long) -> Unit) {
        val buf = ByteArray(128 * dev.blockSize)
        var done = 0L
        while (done < count) {
            val n = minOf(128L, count - done).toInt()
            dev.write(lba + done, buf, n * dev.blockSize)
            done += n
            p(done * 100 / count)
        }
    }

    private fun bootSector(bps: Int, spc: Int, fatSz: Long, total: Long, label: String): ByteArray {
        val b = ByteBuffer.allocate(bps).order(ByteOrder.LITTLE_ENDIAN)
        b.put(0xEB.toByte()).put(0x58).put(0x90.toByte())
        b.put("MSDOS5.0".toByteArray())
        b.putShort(bps.toShort()).put(spc.toByte()).putShort(RESERVED.toShort()).put(FATS.toByte())
        b.putShort(0).putShort(0).put(0xF8.toByte()).putShort(0)
        b.putShort(63).putShort(255).putInt(PART_START.toInt()).putInt(total.toInt())
        b.putInt(fatSz.toInt()).putShort(0).putShort(0).putInt(2).putShort(1).putShort(6)
        b.position(64)
        b.put(0x80.toByte()).put(0).put(0x29).putInt(System.currentTimeMillis().toInt())
        val l = label.uppercase().take(11).padEnd(11, ' ')
        b.put(l.toByteArray()).put("FAT32   ".toByteArray())
        b.put(510, 0x55).put(511, 0xAA.toByte())
        return b.array()
    }

    private fun fsInfo(bps: Int, free: Long): ByteArray {
        val b = ByteBuffer.allocate(bps).order(ByteOrder.LITTLE_ENDIAN)
        b.putInt(0, 0x41615252).putInt(484, 0x61417272).putInt(488, free.toInt()).putInt(492, 3)
        b.put(510, 0x55).put(511, 0xAA.toByte())
        return b.array()
    }
}
