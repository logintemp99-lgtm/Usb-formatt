package com.example.usbformatter

import android.app.Activity
import android.app.AlertDialog
import android.app.PendingIntent
import android.content.*
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.os.Build
import android.os.Bundle
import android.widget.*

class MainActivity : Activity() {
    private val action = "com.example.usbformatter.PERMISSION"
    private lateinit var usb: UsbManager
    private lateinit var status: TextView
    private lateinit var bar: ProgressBar
    private lateinit var label: EditText
    private lateinit var button: Button

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val dev = i.getParcelableExtra<UsbDevice>(UsbManager.EXTRA_DEVICE)
            if (i.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false) && dev != null) confirm(dev)
            else status.text = "Permission denied."
        }
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        usb = getSystemService(USB_SERVICE) as UsbManager
        val f = IntentFilter(action)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, f, RECEIVER_NOT_EXPORTED)
        else registerReceiver(receiver, f)

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 96, 48, 48) }
        status = TextView(this).apply { text = "Plug in a USB drive with an OTG adapter, then tap the button."; textSize = 16f }
        label = EditText(this).apply { setText("USB"); hint = "Volume label" }
        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100 }
        button = Button(this).apply { text = "Format as FAT32"; setOnClickListener { start() } }
        listOf(status, label, bar, button).forEach { root.addView(it) }
        setContentView(root)
    }

    override fun onDestroy() { unregisterReceiver(receiver); super.onDestroy() }

    private fun start() {
        val dev = usb.deviceList.values.firstOrNull { d ->
            (0 until d.interfaceCount).any { d.getInterface(it).interfaceClass == 8 }
        }
        if (dev == null) { status.text = "No USB storage device found."; return }
        if (usb.hasPermission(dev)) confirm(dev)
        else {
            val pi = PendingIntent.getBroadcast(this, 0, Intent(action).setPackage(packageName), PendingIntent.FLAG_MUTABLE)
            usb.requestPermission(dev, pi)
        }
    }

    private fun confirm(dev: UsbDevice) {
        val storage = try { UsbMassStorage.open(usb, dev) } catch (e: Exception) { null }
        if (storage == null) { status.text = "Could not open the drive."; return }
        val gb = storage.blockCount * storage.blockSize / 1e9
        AlertDialog.Builder(this)
            .setTitle("Erase everything?")
            .setMessage("This will permanently erase ALL data on the %.1f GB drive and format it as FAT32.".format(gb))
            .setPositiveButton("Erase and format") { _, _ -> run(storage) }
            .setNegativeButton("Cancel") { _, _ -> storage.close() }
            .show()
    }

    private fun run(storage: UsbMassStorage) {
        button.isEnabled = false
        status.text = "Formatting... do not unplug the drive."
        val name = label.text.toString().ifBlank { "USB" }
        Thread {
            val result = try {
                Fat32Formatter.format(storage, name) { p -> runOnUiThread { bar.progress = p } }
                "Done. Unplug and re-plug the drive."
            } catch (e: Exception) { "Failed: ${e.message}" }
            finally { storage.close() }
            runOnUiThread { status.text = result; button.isEnabled = true }
        }.start()
    }
}
