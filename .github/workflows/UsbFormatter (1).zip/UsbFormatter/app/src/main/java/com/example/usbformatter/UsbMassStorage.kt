package com.example.usbformatter

import android.hardware.usb.*
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Talks SCSI over USB Bulk-Only Transport to a flash drive. */
class UsbMassStorage private constructor(
    private val conn: UsbDeviceConnection,
    private val inEp: UsbEndpoint,
    private val outEp: UsbEndpoint
) {
    var blockSize = 512; private set
    var blockCount = 0L; private set
    private var tag = 1

    companion object {
        private const val CHUNK = 16384

        fun open(manager: UsbManager, device: UsbDevice): UsbMassStorage? {
            for (i in 0 until device.interfaceCount) {
                val intf = device.getInterface(i)
                // class 8 = mass storage, subclass 6 = SCSI, protocol 0x50 = bulk-only
                if (intf.interfaceClass != 8 || intf.interfaceSubclass != 6 || intf.interfaceProtocol != 0x50) continue
                var bIn: UsbEndpoint? = null
                var bOut: UsbEndpoint? = null
                for (e in 0 until intf.endpointCount) {
                    val ep = intf.getEndpoint(e)
                    if (ep.type == UsbConstants.USB_ENDPOINT_XFER_BULK) {
                        if (ep.direction == UsbConstants.USB_DIR_IN) bIn = ep else bOut = ep
                    }
                }
                if (bIn == null || bOut == null) continue
                val c = manager.openDevice(device) ?: return null
                if (!c.claimInterface(intf, true)) { c.close(); return null }
                val s = UsbMassStorage(c, bIn, bOut)
                s.readCapacity()
                return s
            }
            return null
        }
    }

    fun close() = conn.close()

    private fun command(cb: ByteArray, dataLen: Int, dataIn: Boolean, buf: ByteArray?, off: Int) {
        val cbw = ByteBuffer.allocate(31).order(ByteOrder.LITTLE_ENDIAN)
        cbw.putInt(0x43425355).putInt(tag++).putInt(dataLen)
        cbw.put(if (dataIn) 0x80.toByte() else 0).put(0).put(cb.size.toByte()).put(cb)
        check(conn.bulkTransfer(outEp, cbw.array(), 31, 5000) == 31) { "CBW failed" }
        var done = 0
        while (done < dataLen) {
            val n = minOf(CHUNK, dataLen - done)
            val ep = if (dataIn) inEp else outEp
            val r = conn.bulkTransfer(ep, buf, off + done, n, 10000)
            check(r > 0) { "Data transfer failed" }
            done += r
        }
        val csw = ByteArray(13)
        check(conn.bulkTransfer(inEp, csw, 13, 5000) == 13) { "CSW failed" }
        check(csw[12].toInt() == 0) { "Drive reported an error (write-protected or faulty?)" }
    }

    private fun readCapacity() {
        val r = ByteArray(8)
        command(byteArrayOf(0x25, 0, 0, 0, 0, 0, 0, 0, 0, 0), 8, true, r, 0)
        val b = ByteBuffer.wrap(r).order(ByteOrder.BIG_ENDIAN)
        val last = b.int.toLong() and 0xFFFFFFFFL
        blockSize = b.int
        check(last != 0xFFFFFFFFL) { "Drives over 2 TB are not supported" }
        blockCount = last + 1
    }

    /** Writes whole blocks starting at lba. data.size must be a multiple of blockSize. */
    fun write(lba: Long, data: ByteArray, length: Int = data.size) {
        var pos = 0
        var cur = lba
        val maxBlocks = 128
        while (pos < length) {
            val blocks = minOf(maxBlocks, (length - pos) / blockSize)
            val cb = ByteBuffer.allocate(10).order(ByteOrder.BIG_ENDIAN)
            cb.put(0x2A).put(0).putInt(cur.toInt()).put(0).putShort(blocks.toShort()).put(0)
            command(cb.array(), blocks * blockSize, false, data, pos)
            pos += blocks * blockSize
            cur += blocks
        }
    }
}
